# Changelog

## 2019-11-27

- [Feature] App now saves the last interval value
- [Feature] Add option to increase/decrease time by 1 minute using screen
  buttons (BTN4 and BTN5)
- [Bugfix] Fixed newlines in message
- [Chore] Renamed to Pomodoro
