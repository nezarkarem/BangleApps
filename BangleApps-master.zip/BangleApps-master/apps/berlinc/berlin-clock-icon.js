require("heatshrink").decompress(atob("mEwwkBDa8M5gADh//AAYFK+AX/C/4X/C98AACwvFGqBHGC/4X/C/4XpgAAWh3u9wCCF4PAAgIoB+AtDAgoX/C/4X/C98AACwpBAAYFLFgIAC+AX/C/4X/C67/PAA4A=="))
