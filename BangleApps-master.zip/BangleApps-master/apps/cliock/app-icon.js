require("heatshrink").decompress(atob("mEwgRC/AH4Ae/4AEBaPwAgcPBaIvvBZkL8ED6ALHl/4+XgBY89vnw+ALHngDB+gLK3AjKng7JBwJTJgEfO76/iAH4A/ADAA="))
