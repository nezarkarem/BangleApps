# BLE Detector

BLE Detector it's an app born for testing purpose that aim to show as informations as possible about near BLE devices.

## Features

BLE Detector shows:

- Device name (if available)
- Received Signal Strength Indication (RSSI)
- Manufacturer
- MAC Address

More informations will coming with future versions.
