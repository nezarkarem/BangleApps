# Pipboy themed clock
Have your own Pip-Boy (based on Java Script)

![](pipboy-screenshot.png)

## Features

* High-end greenscreen design
* Shows all your stats
* Time
* Date
* STIMPAKS left
* RADAWAY left
* Health remaining (shows current day in year / days in year)
* Your Level (Shows day in week and progress bar for time passed in day)

## Requests

If you have any feature requests, please contact the original author https://twitter.com/simons_bird or co-author http://forum.espruino.com/profiles/155005/