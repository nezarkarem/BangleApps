(function(back) {
  // just go right to our app
  load("gpssetup.app.js");
})();
