(function(back) {
  // just go right to our app
  load("gpsservice.app.js");
})();
