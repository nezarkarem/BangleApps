# BLE GATT Battery Service

Adds the GATT Battery Service to advertise the percentage of battery currently remaining over Bluetooth.

## Usage

This boot code runs in the background and has no user interface.

## Requests

If you have any suggestions or ideas please post in [this forum thread](http://forum.espruino.com/conversations/351959/),
or [@jjok](https://github.com/jjok) in your Github issue.

## Creator

[Jonathan Jefferies](https://github.com/jjok)
