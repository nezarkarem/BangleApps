# hello, world!

A cross cultural hello world!/hola mundo! app
The most common testing sentence in several languages ;)


## Pictures:

Launcher icon

![](helloworld_icon.png)

Screen - Spanish

![](helloworld_es.png)

Screen - English

![](helloworld_en.png)

Screen - Japanese

![](helloworld_jp.png)



## Usage

Open and see a hello, World! in the screen 
interact to change language, color or quit.

## Features

Colours, all inputs , graph, widgets loaded 
Counter for Times Display


## Controls

finger swipe 
button 1,2 and 3
touch screen left, center or right


## Creator

Daniel Perez