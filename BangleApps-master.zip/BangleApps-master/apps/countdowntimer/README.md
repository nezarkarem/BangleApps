# countdown-timer

A basic bangle.js timer with a focus on usability.

* Start or Pause the timer with BTN1
* Reset the timer with BTN2
* Exit the application with BTN3
* Touch the right side of the screen to increase the time amount by 1 second
* Touch the left side of the scren to decrease the time amount by 1 second
* Touching and holding the screen will increase or decrease the time amount by 60 seconds at a time.

Icons made by [Freepik](https://www.freepik.com) from [Flaticon](https://www.flaticon.com/).
