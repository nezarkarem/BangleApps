# Intervals app
Just my first app to test this amazing smartwatch.

The idea is to create a simple app which allows to define a workout, being able to configure the work time, rest time and number of sets. Try it out, it is quite simple.

This is obviously version 0.01 but it should work.