Bangle.on("charging", isCharging => { if (isCharging) load("chargeanim.app.js"); });
