require("heatshrink").decompress(atob("mEwwkCIf4A/AH4A/AH4A/AA8RAAgHBgIHEiAXIp3uAAdQgEeA4ngC/4XoqlEAAaHBigHEoAQBgtVAAK4Thw2CC/4X/C8cBiIABC6YA/AH4A/AH4A/AHw"))
