# Battleship

The classic game of battleship.

## Usage

In the beginning, each player is required to place
all ships in his fleet on the field.
Navigation of the cursor is performed using BTN1 and
BTN3 as well as left and right on the touch screen.
To place a ship use BTN2 to initialize a placement
and BTN2 again to complete it.

In the next phase the players take alternating turns
in trying to hit an opposing ship.

After a player succeeds in sinking the entire opposing
fleet the game ends.
