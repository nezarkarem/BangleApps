(function(back) {
  // just go right to our app - we need all the memory
  load("gpsrec.app.js");
})();
