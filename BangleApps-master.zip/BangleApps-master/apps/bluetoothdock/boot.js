Bangle.on("charging", isCharging => { if (isCharging) load("bluetoothdock.app.js"); });
