# Points Of Interest Compass

## Description

Uploads all the points of interest in an area onto your watch, same as Beer Compass with more p.o.i.

## Requests

If you have any bug or feature request, please contact [Renaudgweb](https://github.com/renaudgweb/)
