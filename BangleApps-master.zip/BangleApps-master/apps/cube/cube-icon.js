require("heatshrink").decompress(atob("/4AYv4CB+YdZABPvEkYA/AGv3EkfPAQP+DrI"))
