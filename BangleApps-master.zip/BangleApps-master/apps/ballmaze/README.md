# Ball Maze

Navigate a ball through a maze by tilting your watch.

![Screenshot](size_select.png)
![Screenshot](maze.png)

## Usage

Select a maze size to begin the game.   
Tilt your watch to steer the ball towards the target and advance to the next level.

## Creator

Richard de Boer <rigrig+banglejs@tubul.net>
