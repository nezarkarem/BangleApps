# Find Phone

Ring your phone via GadgetBridge if you lost it somewhere.

1. Connect GadgetBridge
2. Lose phone
3. Open app
4. Click any button or screen
