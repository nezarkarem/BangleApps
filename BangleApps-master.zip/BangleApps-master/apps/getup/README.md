# Get Up

Reminds you to getup every x minutes (default: 20).

Sitting to long is dangerous!

Sit and move time configurable in settings.
