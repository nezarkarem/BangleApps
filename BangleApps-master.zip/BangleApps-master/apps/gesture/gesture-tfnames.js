"swipeleft,swiperight,upup,waggle,clap2"
