# Pong

A clone of the Atari game Pong

<img src="https://user-images.githubusercontent.com/702227/79855656-2a507a00-83c3-11ea-9162-65732729b992.png" height="384" width="384" />

## Features 

- Play against a dumb AI
- Play local Multiplayer against your friends

## Controls

Player's controls:
- UP: BTN1
- DOWN: BTN2
long press to move faster

Restart a game:
- RESET: BTN3

Buttons for player 2:
- UP: BTN4
- DOWN: BTN5

## Creator

<https://twitter.com/fredericrous>
