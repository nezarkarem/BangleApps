# Desktop style App Launcher

![](screenshot.jpg)

In the picture above, the Settings app is selected.
## Controls

**BTN1** - move backward through app icons on a page

**BTN2** - run the selected app

**BTN3** - move forward through app icons

**Swipe Left** -  move to next page of app icons

**Swipe Right** - move to previous page of app icons