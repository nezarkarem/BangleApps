# Numerals Clock

This is a simple big numerals clock.
Settings can be accessed through the app/widget settings menu of the Bangle.js

## Settings available

### Color:
* rnd - shows numerals in different color combinations every time the watches wakes
* r/g - red/green
* y/w - yellow/white 
* o/c - orange/cyan
* b/y - blue/yellow'ish

### Draw mode
* fill - fill numerals
* frame - only shows outline of numerals

### Menu button
* choose button to start launcher menu with

### Date on touch
* shows the current date as DD MM on touch and reverts back to time after 5 seconds